"""
xlsx_parser.py — Extracts demographics, device Results-sheet values, and
raw breath-by-breath data from a COSMED K5 CPET export (the exact format
established from Almar Viðarsson's file: 'Data' + 'Results' sheets).
"""
import openpyxl
from datetime import time


def _t_to_sec(t):
    if isinstance(t, time):
        return t.hour * 3600 + t.minute * 60 + t.second
    return None


def parse_demographics(ws):
    """Pull the key-value metadata block from the top of the Data sheet."""
    demo = {}
    for r in range(1, 12):
        for pair_start in (1, 4, 7):
            k = ws.cell(r, pair_start).value
            v = ws.cell(r, pair_start + 1).value
            if k:
                demo[str(k).strip()] = v
    return demo


def parse_results_sheet(ws):
    """
    Pull the device's own Rest/Warm-Up/FatMax/VT1/VT2/Max breakdown.
    Column layout: 1=Parameter 2=um 3=Meas 4=Rest 5=Warm-Up 6=FatMax
    7=VT1 8=VT2 9=Max 10=Pred 11=%Pred 12=Normal 13=Class
    """
    results = {}
    for r in range(1, ws.max_row + 1):
        param = ws.cell(r, 1).value
        if not param:
            continue
        results[str(param).strip()] = {
            'unit': ws.cell(r, 2).value,
            'rest': ws.cell(r, 4).value,
            'warmup': ws.cell(r, 5).value,
            'fatmax': ws.cell(r, 6).value,
            'vt1': ws.cell(r, 7).value,
            'vt2': ws.cell(r, 8).value,
            'max': ws.cell(r, 9).value,
            'pred': ws.cell(r, 10).value,
            'pct_pred': ws.cell(r, 11).value,
            'normal': ws.cell(r, 12).value,
            'class': ws.cell(r, 13).value,
        }
    return results


# Data-sheet column indices (1-based), matching the established format
COLS = {
    't': 10, 'rf': 11, 'vt': 12, 've': 13, 'vo2': 15, 'vco2': 16,
    'rq': 17, 'vo2kg': 22, 'hr': 24, 'phase': 36,
}


def parse_breath_data(ws, phase='EXERCISE'):
    """Extract clean breath-by-breath rows for a given test phase."""
    rows = []
    for r in range(4, ws.max_row + 1):
        if ws.cell(r, COLS['phase']).value != phase:
            continue
        t = _t_to_sec(ws.cell(r, COLS['t']).value)
        hr = ws.cell(r, COLS['hr']).value
        vo2kg = ws.cell(r, COLS['vo2kg']).value
        vco2_abs = ws.cell(r, COLS['vco2']).value
        rq = ws.cell(r, COLS['rq']).value
        ve = ws.cell(r, COLS['ve']).value
        rf = ws.cell(r, COLS['rf']).value
        vt = ws.cell(r, COLS['vt']).value
        if None in (t, hr, vo2kg, vco2_abs, rq, ve, rf, vt):
            continue
        rows.append({'t': t, 'hr': hr, 'vo2': vo2kg, 'vco2_abs': vco2_abs,
                      'rer': rq, 've': ve, 'vt': vt, 'bf': rf})
    return rows


def bin_breaths(rows, weight_kg, n_stages=14):
    """Bin raw breaths into N equal time-windows (mean aggregation)."""
    if not rows:
        return []
    t0, t1 = rows[0]['t'], rows[-1]['t']
    bin_width = (t1 - t0) / n_stages
    stages = []
    for i in range(n_stages):
        lo, hi = t0 + i * bin_width, t0 + (i + 1) * bin_width
        bucket = [r for r in rows if lo <= r['t'] < hi] or [rows[-1]]
        def avg(key):
            return sum(r[key] for r in bucket) / len(bucket)
        vco2_abs = avg('vco2_abs')
        stages.append({
            's': i + 1, 't': round(hi - t0) if i < n_stages - 1 else round(t1 - t0),
            'hr': round(avg('hr')), 'vo2': round(avg('vo2'), 1),
            'vco2': round(vco2_abs / weight_kg, 1),
            'rer': round(avg('rer'), 2), 've': round(avg('ve'), 1),
            'vt': round(avg('vt'), 2), 'bf': round(avg('bf'), 1),
        })
    return stages


def _find_demo_value(demo, *candidates):
    """Look up a demographic value trying several possible key spellings."""
    for c in candidates:
        if c in demo:
            return demo[c]
        # also try case-insensitive substring match
        for k in demo:
            if c.lower() in k.lower():
                return demo[k]
    return None


def parse_cpet_file(filepath):
    """Full pipeline: xlsx -> demographics + results + binned stages + raw breaths."""
    wb = openpyxl.load_workbook(filepath, data_only=True)
    ws_data = wb['Data']
    ws_results = wb['Results'] if 'Results' in wb.sheetnames else None

    demo = parse_demographics(ws_data)
    results = parse_results_sheet(ws_results) if ws_results else {}

    weight_val = _find_demo_value(demo, 'Weight (kg)', 'Weight')
    weight = float(weight_val) if weight_val is not None else 70.0

    raw_breaths = parse_breath_data(ws_data, phase='EXERCISE')
    binned_stages = bin_breaths(raw_breaths, weight, n_stages=14)

    return {
        'demographics': demo,
        'results': results,
        'weight_kg': weight,
        'raw_breaths': raw_breaths,
        'stages': binned_stages,
    }
