"""
main.py — SportLab K5 Report Platform.
Internal tool: staff log in, upload a COSMED K5 xlsx export, get an
auto-generated report, browse athlete history, share a view link.
"""
import os
import shutil
import secrets
from datetime import datetime, date
from pathlib import Path

from fastapi import FastAPI, Request, UploadFile, File, Form, Depends, HTTPException, status
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from itsdangerous import URLSafeSerializer, BadSignature
from sqlalchemy.orm import Session

from models import init_db, get_session, Athlete, Report
from xlsx_parser import parse_cpet_file
from detection import detect_thresholds
from report_renderer import render_report, _fmt_date

BASE_DIR = Path(__file__).parent.parent
UPLOAD_DIR = BASE_DIR / 'uploads'
UPLOAD_DIR.mkdir(exist_ok=True)

SECRET_KEY = os.environ.get('SECRET_KEY', secrets.token_hex(32))
STAFF_PASSWORD = os.environ.get('STAFF_PASSWORD', 'change-me')
serializer = URLSafeSerializer(SECRET_KEY)

app = FastAPI(title='SportLab K5 Platform')
templates = Jinja2Templates(directory=str(BASE_DIR / 'templates'))

init_db()


# ─── Auth helpers ────────────────────────────────────────
def get_current_user(request: Request):
    token = request.cookies.get('session')
    if not token:
        return None
    try:
        data = serializer.loads(token)
        return data.get('user')
    except BadSignature:
        return None


def require_login(request: Request):
    user = get_current_user(request)
    if not user:
        raise HTTPException(status_code=status.HTTP_303_SEE_OTHER, headers={'Location': '/login'})
    return user


# ─── Routes: auth ────────────────────────────────────────
@app.get('/login', response_class=HTMLResponse)
def login_page(request: Request):
    if get_current_user(request):
        return RedirectResponse('/', status_code=303)
    return templates.TemplateResponse('login.html', {'request': request, 'error': None})


@app.post('/login')
def login_submit(request: Request, password: str = Form(...)):
    if password != STAFF_PASSWORD:
        return templates.TemplateResponse('login.html', {'request': request, 'error': 'Incorrect password'})
    token = serializer.dumps({'user': 'staff'})
    resp = RedirectResponse('/', status_code=303)
    resp.set_cookie('session', token, httponly=True, samesite='lax', max_age=60 * 60 * 24 * 30)
    return resp


@app.get('/logout')
def logout():
    resp = RedirectResponse('/login', status_code=303)
    resp.delete_cookie('session')
    return resp


# ─── Routes: dashboard ───────────────────────────────────
@app.get('/', response_class=HTMLResponse)
def dashboard(request: Request, db: Session = Depends(get_session)):
    user = get_current_user(request)
    if not user:
        return RedirectResponse('/login', status_code=303)
    athletes = db.query(Athlete).order_by(Athlete.name).all()
    recent_reports = db.query(Report).order_by(Report.uploaded_at.desc()).limit(15).all()
    return templates.TemplateResponse('dashboard.html', {
        'request': request, 'athletes': athletes, 'recent_reports': recent_reports,
    })


@app.get('/upload', response_class=HTMLResponse)
def upload_page(request: Request):
    if not get_current_user(request):
        return RedirectResponse('/login', status_code=303)
    return templates.TemplateResponse('upload.html', {'request': request, 'error': None})


@app.post('/upload')
async def upload_submit(request: Request, file: UploadFile = File(...), db: Session = Depends(get_session)):
    if not get_current_user(request):
        return RedirectResponse('/login', status_code=303)

    if not file.filename.lower().endswith('.xlsx'):
        return templates.TemplateResponse('upload.html', {
            'request': request, 'error': 'Please upload a .xlsx file exported from the K5.'
        })

    # Save the uploaded file
    dest = UPLOAD_DIR / f'{datetime.utcnow().timestamp():.0f}_{file.filename}'
    with open(dest, 'wb') as f:
        shutil.copyfileobj(file.file, f)

    try:
        parsed = parse_cpet_file(str(dest))
    except Exception as e:
        return templates.TemplateResponse('upload.html', {
            'request': request, 'error': f"Couldn't parse this file: {e}"
        })

    if not parsed['stages']:
        return templates.TemplateResponse('upload.html', {
            'request': request, 'error': 'No EXERCISE-phase breath data found in this file.'
        })

    vt_result = detect_thresholds(parsed['stages'], parsed['weight_kg'])

    demo = parsed['demographics']
    full_name = f"{demo.get('First Name', '')} {demo.get('Last Name', '')}".strip() or 'Unknown Athlete'
    dob = str(demo.get('D.O.B.', ''))
    gender = demo.get('Gender', '')
    test_date_raw = demo.get('Test date', '')

    # Find or create the athlete (matched by name — simple for an
    # internal tool; swap for a proper athlete ID system if needed)
    athlete = db.query(Athlete).filter(Athlete.name == full_name).first()
    if not athlete:
        athlete = Athlete(name=full_name, dob=dob, gender=gender)
        db.add(athlete)
        db.commit()
        db.refresh(athlete)

    # Look up this athlete's most recent prior report for trend auto-fill
    previous = (db.query(Report)
                .filter(Report.athlete_id == athlete.id)
                .order_by(Report.uploaded_at.desc())
                .first())
    previous_dict = None
    if previous:
        previous_dict = {
            'vo2max': previous.vo2max, 'vt1_hr': previous.vt1_hr,
            'vt2_hr': previous.vt2_hr, 'hrmax': previous.hrmax,
            'test_date': _fmt_date(previous.test_date),
        }

    # Generate a sequential report ID
    year = date.today().year
    count = db.query(Report).count() + 1
    report_id = f'SL-{year}-{count:04d}'

    html = render_report(parsed, vt_result, report_id, previous_report=previous_dict)

    vo2kg = parsed['results'].get('VO2/Kg', {})
    hr_res = parsed['results'].get('HR', {})

    report = Report(
        report_id=report_id, athlete_id=athlete.id, test_date=test_date_raw,
        source_filename=file.filename,
        vo2max=vo2kg.get('max'), hrmax=hr_res.get('max'),
        vt1_hr=round(vt_result['vt1']['hr']) if vt_result['vt1']['hr'] else None,
        vt2_hr=round(vt_result['vt2']['hr']) if vt_result['vt2']['hr'] else None,
        html_content=html,
    )
    db.add(report)
    db.commit()
    db.refresh(report)

    dest.unlink(missing_ok=True)  # don't keep the raw xlsx around
    return RedirectResponse(f'/report/{report.report_id}', status_code=303)


@app.get('/athlete/{athlete_id}', response_class=HTMLResponse)
def athlete_history(request: Request, athlete_id: int, db: Session = Depends(get_session)):
    if not get_current_user(request):
        return RedirectResponse('/login', status_code=303)
    athlete = db.query(Athlete).filter(Athlete.id == athlete_id).first()
    if not athlete:
        raise HTTPException(404)
    return templates.TemplateResponse('athlete.html', {'request': request, 'athlete': athlete})


@app.get('/report/{report_id}', response_class=HTMLResponse)
def view_report(report_id: str, db: Session = Depends(get_session)):
    # Deliberately no login check — this is the shareable link staff
    # send to a customer. The report_id itself (e.g. SL-2026-0042) acts
    # as the access token; anyone with the link can view it, nobody can
    # browse/enumerate other reports without knowing their IDs.
    report = db.query(Report).filter(Report.report_id == report_id).first()
    if not report:
        raise HTTPException(404, 'Report not found')
    return Response(content=report.html_content, media_type='text/html')


static_dir = BASE_DIR / 'static'
static_dir.mkdir(exist_ok=True)
app.mount('/static', StaticFiles(directory=str(static_dir)), name='static')
