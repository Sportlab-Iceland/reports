"""models.py — SQLAlchemy models for the SportLab platform."""
from sqlalchemy import create_engine, Column, Integer, String, Float, Text, DateTime, ForeignKey
from sqlalchemy.orm import declarative_base, relationship, sessionmaker
from datetime import datetime
import os

from pathlib import Path

_DEFAULT_DB_PATH = Path(__file__).parent.parent / 'sportlab.db'
DATABASE_URL = os.environ.get('DATABASE_URL', f'sqlite:///{_DEFAULT_DB_PATH}')
# Render/Heroku-style URLs sometimes use postgres:// — SQLAlchemy needs postgresql://
if DATABASE_URL.startswith('postgres://'):
    DATABASE_URL = DATABASE_URL.replace('postgres://', 'postgresql://', 1)

engine = create_engine(DATABASE_URL, connect_args={'check_same_thread': False} if 'sqlite' in DATABASE_URL else {})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()


class Athlete(Base):
    __tablename__ = 'athletes'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    dob = Column(String)
    gender = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

    reports = relationship('Report', back_populates='athlete', order_by='Report.test_date.desc()')


class Report(Base):
    __tablename__ = 'reports'
    id = Column(Integer, primary_key=True)
    report_id = Column(String, unique=True, nullable=False)  # e.g. SL-2026-0042
    athlete_id = Column(Integer, ForeignKey('athletes.id'), nullable=False)
    test_date = Column(String)
    uploaded_at = Column(DateTime, default=datetime.utcnow)
    source_filename = Column(String)

    # Key metrics stored separately for fast history lookups (used to
    # auto-fill "Trend vs. Previous Test" on the next report)
    vo2max = Column(Float)
    vt1_hr = Column(Integer)
    vt2_hr = Column(Integer)
    hrmax = Column(Integer)

    html_content = Column(Text, nullable=False)  # the full rendered report

    athlete = relationship('Athlete', back_populates='reports')


def init_db():
    Base.metadata.create_all(bind=engine)


def get_session():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
