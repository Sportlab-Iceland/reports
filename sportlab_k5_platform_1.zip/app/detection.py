"""
detection.py — Automated VT1/VT2 detection from breath-by-breath or
binned CPET data. Python port of the two-method algorithm validated in
the SportLab K5 report against Almar Viðarsson's file (exact HR match
at VT1, within 3 bpm at VT2 vs. the device's own clinical detection).

Method A — V-slope (Beaver, Wasserman & Whipp, 1986): two-segment
           regression breakpoint on VCO2 vs VO2 (VT1) and VE vs VCO2 (VT2).
Method B — Ventilatory equivalents: nadir + sustained-rise confirmation
           on VE/VO2 (VT1) and VE/VCO2 (VT2).
Final result = mean of the two methods, per Gaskill et al. (2001).
"""


def _segment_ssr(x, y):
    n = len(x)
    if n < 2:
        return 0
    mx, my = sum(x) / n, sum(y) / n
    num = sum((x[i] - mx) * (y[i] - my) for i in range(n))
    den = sum((x[i] - mx) ** 2 for i in range(n))
    slope = num / den if den else 0
    intercept = my - slope * mx
    return sum((y[i] - (slope * x[i] + intercept)) ** 2 for i in range(n))


def _two_segment_breakpoint(x, y):
    n = len(x)
    best_k, best_ssr = n // 2, float('inf')
    for k in range(3, n - 3):
        ssr = _segment_ssr(x[:k + 1], y[:k + 1]) + _segment_ssr(x[k:], y[k:])
        if ssr < best_ssr:
            best_ssr, best_k = ssr, k
    return best_k


def _nadir_with_confirmation(series, start_from):
    for i in range(start_from, len(series) - 2):
        if series[i] <= series[i - 1] and series[i + 1] > series[i] and series[i + 2] > series[i + 1]:
            return i
    return min(range(start_from, len(series)), key=lambda i: series[i])


def _interp_at(stages, field, frac_idx):
    i0 = max(0, min(len(stages) - 1, int(frac_idx)))
    i1 = min(len(stages) - 1, i0 + 1)
    v0, v1 = stages[i0].get(field), stages[i1].get(field)
    if v0 is None or v1 is None:
        return None
    frac = frac_idx - i0
    return v0 + frac * (v1 - v0)


def detect_thresholds(stages, weight_kg):
    """
    stages: list of dicts with keys s,t,hr,vo2,vco2,rer,ve,vt,bf
            (vo2/vco2 in ml/kg/min, relative)
    Returns dict with vt1 and vt2, each {frac, hr, vo2, sp}
    """
    vo2_abs = [r['vo2'] * weight_kg / 1000 for r in stages]
    vco2_abs = [r['vco2'] * weight_kg / 1000 for r in stages]
    ve_arr = [r['ve'] for r in stages]

    # Method A — V-slope. Restrict VT1 search to the sub-VT2 domain
    # (RER < 1.05) so the more dramatic late-test slope change doesn't
    # dominate the fit (Beaver 1986; Ekkekakis 2008).
    sub_vt2_end = next((i for i, r in enumerate(stages) if r['rer'] > 1.05), len(stages))
    vt1_search_len = sub_vt2_end + 1 if sub_vt2_end < len(stages) else len(stages)
    vt1_vslope = _two_segment_breakpoint(vo2_abs[:vt1_search_len], vco2_abs[:vt1_search_len])
    vt2_vslope = _two_segment_breakpoint(vco2_abs, ve_arr)

    # Method B — Ventilatory equivalents
    ve_vo2 = [ve / vo2_abs[i] for i, ve in enumerate(ve_arr)]
    ve_vco2 = [ve / vco2_abs[i] for i, ve in enumerate(ve_arr)]
    vt1_veq = _nadir_with_confirmation(ve_vo2, 1)
    vt2_veq = _nadir_with_confirmation(ve_vco2, max(vt1_veq + 1, 1))

    vt1_frac = (vt1_vslope + vt1_veq) / 2
    vt2_frac = max(vt1_frac + 0.5, (vt2_vslope + vt2_veq) / 2)

    def threshold_at(frac):
        return {
            'frac': frac,
            'hr': _interp_at(stages, 'hr', frac),
            'vo2': _interp_at(stages, 'vo2', frac),
            'sp': _interp_at(stages, 'sp', frac) if 'sp' in stages[0] else None,
        }

    return {
        'vt1': threshold_at(vt1_frac),
        'vt2': threshold_at(vt2_frac),
        'method_detail': {
            'vt1_vslope_idx': vt1_vslope, 'vt1_veq_idx': vt1_veq,
            'vt2_vslope_idx': vt2_vslope, 'vt2_veq_idx': vt2_veq,
        }
    }
