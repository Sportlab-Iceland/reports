"""
report_renderer.py — Takes parsed CPET data and produces a complete,
self-contained HTML report by substituting real values into the proven
SportLab K5 template (templates/report_template.html).

Design choice: demographics, hero metrics, and all chart/stage data are
auto-populated from real data. Narrative sections (Physiological Summary,
Training Recommendations, Event Suitability) are left as sensible,
contenteditable defaults for staff to review and personalize — CPET
interpretation benefits from a human in the loop, and every field in
the report is click-to-edit in the browser regardless.
"""
import json
import re
from pathlib import Path

TEMPLATE_PATH = Path(__file__).parent.parent / 'templates' / 'report_template.html'


def _fmt_date(raw):
    """Normalize a date string like '14.2.2023' to '14 February 2023'."""
    if not raw:
        return '— add date —'
    months = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
              'August', 'September', 'October', 'November', 'December']
    try:
        parts = str(raw).split('.')
        if len(parts) == 3:
            d, m, y = int(parts[0]), int(parts[1]), int(parts[2])
            return f'{d} {months[m-1]} {y}'
    except (ValueError, IndexError):
        pass
    return str(raw)


def _classify_vo2max(pct_pred):
    """ACSM-style classification band from % predicted."""
    if pct_pred is None:
        return ''
    if pct_pred >= 130:
        return 'Superior'
    if pct_pred >= 110:
        return 'Excellent'
    if pct_pred >= 90:
        return 'Good'
    if pct_pred >= 75:
        return 'Fair'
    return 'Poor'


def build_stage_data_js(stages, weight_kg):
    """Build the STAGE_DATA JS array literal (sp/g/rpe null — no workload logged)."""
    lines = []
    for r in stages:
        lines.append(
            f"  {{ s: {r['s']}, t: {r['t']}, sp: null, g: null, hr: {r['hr']}, "
            f"vo2: {r['vo2']}, vco2: {r['vco2']}, rer: {r['rer']}, ve: {r['ve']}, "
            f"vt: {r['vt']}, bf: {r['bf']}, rpe: null }},"
        )
    return "const STAGE_DATA = [\n" + "\n".join(lines) + "\n];"


def build_raw_breaths_js(raw_breaths):
    """Build the RAW_BREATHS JS array: [t,hr,vo2,vco2_relative,rer,ve,vt,bf]."""
    entries = []
    for b in raw_breaths:
        # vco2_abs needs converting to relative for consistency with STAGE_DATA
        entries.append([b['t'], b['hr'], b['vo2'], b['vco2_abs'], b['rer'], b['ve'], b['vt'], b['bf']])
    return "const RAW_BREATHS = " + json.dumps(entries, separators=(',', ':')) + ";"


def render_report(parsed, vt_result, report_id, previous_report=None):
    """
    parsed: output of xlsx_parser.parse_cpet_file()
    vt_result: output of detection.detect_thresholds()
    report_id: string, e.g. 'SL-2026-0042'
    previous_report: optional dict with keys vo2max, vt1_hr, vt2_hr, hrmax,
                      test_date — from the athlete's last stored report.
                      When provided, the Trend table's "Previous Test"
                      column is pre-filled with real data instead of
                      being left for manual entry.
    Returns: complete HTML string
    """
    demo = parsed['demographics']
    results = parsed['results']
    weight = parsed['weight_kg']
    stages = parsed['stages']

    with open(TEMPLATE_PATH, encoding='utf-8') as f:
        html = f.read()

    # ── Demographics ──
    first = demo.get('First Name', '')
    last = demo.get('Last Name', '')
    full_name = f'{first} {last}'.strip() or '— add name —'
    dob = _fmt_date(demo.get('D.O.B.'))
    test_date = _fmt_date(demo.get('Test date'))
    age = demo.get('Age')
    age_str = f'{int(age)}' if age else '—'
    gender = demo.get('Gender', '—')
    height = demo.get('Height (cm)')
    height_str = f'{height} cm' if height else '— add height —'
    weight_str = f'{weight} kg' if weight else '— add weight —'

    replacements = [
        ('Almar Viðarsson', full_name),
        ('3 September 1981', dob),
        ('41 · Male', f'{age_str} · {gender}'),
        ('163.3 cm', height_str),
        ('72.1 kg', weight_str),
        ('14 February 2023', test_date),
        ('SL-2026-0184', report_id),
    ]
    for old, new in replacements:
        html = html.replace(old, new)

    # ── Hero metrics (from device Results sheet where available) ──
    vo2kg = results.get('VO2/Kg', {})
    hr_res = results.get('HR', {})
    rq_res = results.get('RQ', {})
    ve_res = results.get('VE', {})
    br_res = results.get('BR', {})

    vo2max = vo2kg.get('max')
    vo2max_pct = vo2kg.get('pct_pred')
    vo2max_class = vo2kg.get('class') or _classify_vo2max(vo2max_pct)
    hrmax = hr_res.get('max')
    hrmax_pred = hr_res.get('pred')
    rermax = rq_res.get('max')
    vemax = ve_res.get('max')
    br_max = br_res.get('max')
    effort_flag = demo.get('Maximal Effort', 'Unconfirmed')

    if vo2max is not None:
        html = html.replace('>57.1<', f'>{vo2max}<')
    if vo2max_pct is not None and vo2max_class:
        html = html.replace('141 % · Superior', f'{vo2max_pct:.0f} % · {vo2max_class}')
    if hrmax is not None:
        html = html.replace('>182<', f'>{hrmax}<')
    if hrmax_pred is not None:
        html = html.replace('>179</span>', f'>{hrmax_pred}</span>')
    if rermax is not None:
        html = html.replace('>1.09<', f'>{rermax}<')
    html = html.replace('Unconfirmed (device flag)', f'{effort_flag} (device flag)')
    if vemax is not None:
        html = html.replace('>112.8<', f'>{vemax}<')
    if br_max is not None:
        html = html.replace('18.5 %', f'{br_max} %')

    # ── VT1/VT2/FATmax from live detection + device FatMax reading ──
    vt1, vt2 = vt_result['vt1'], vt_result['vt2']
    fatmax_vo2kg = vo2kg.get('fatmax')
    fatmax_hr = hr_res.get('fatmax')
    if fatmax_vo2kg and vo2max:
        fatmax_pct_vo2max = round(fatmax_vo2kg / vo2max * 100)
        html = html.replace('64% VO₂max · 122 bpm', f'{fatmax_pct_vo2max}% VO₂max · {fatmax_hr} bpm')

    # ── Stage table / chart data ──
    stage_data_js = build_stage_data_js(stages, weight)
    raw_breaths_js = build_raw_breaths_js(parsed['raw_breaths'])

    old_stage_match = re.search(r'const STAGE_DATA = \[.*?\n\];', html, re.DOTALL)
    if old_stage_match:
        html = html[:old_stage_match.start()] + stage_data_js + html[old_stage_match.end():]

    old_raw_match = re.search(r'const RAW_BREATHS = \[.*?\];', html, re.DOTALL)
    if old_raw_match:
        html = html[:old_raw_match.start()] + raw_breaths_js + html[old_raw_match.end():]

    # ── Trend vs. Previous Test — auto-fill from real stored history ──
    if previous_report:
        trend_subs = [
            ('data-trend="vo2max" data-current="">—<',
             f'data-trend="vo2max" data-current="">{previous_report.get("vo2max", "—")}<'),
            ('data-trend="vt1">—<', f'data-trend="vt1">{previous_report.get("vt1_hr", "—")}<'),
            ('data-trend="vt2">—<', f'data-trend="vt2">{previous_report.get("vt2_hr", "—")}<'),
            ('data-trend="hrmax">—<', f'data-trend="hrmax">{previous_report.get("hrmax", "—")}<'),
            ('data-trend="date">— add previous date —<',
             f'data-trend="date">{previous_report.get("test_date", "—")}<'),
        ]
        for old, new in trend_subs:
            html = html.replace(old, new)

    return html
